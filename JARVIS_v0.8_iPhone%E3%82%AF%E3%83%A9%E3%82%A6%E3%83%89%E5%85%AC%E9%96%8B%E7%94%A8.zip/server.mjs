import http from 'node:http';
import {readFile} from 'node:fs/promises';
import {join} from 'node:path';
import {timingSafeEqual} from 'node:crypto';
const port=Number(process.env.PORT||3000);
const key=process.env.OPENAI_API_KEY;
const password=process.env.JARVIS_PASSWORD;
const model=process.env.OPENAI_MODEL||'gpt-4.1-mini';
const mime={'/':'text/html; charset=utf-8','/index.html':'text/html; charset=utf-8','/icon.svg':'image/svg+xml','/manifest.webmanifest':'application/manifest+json'};
const files={'/':'index.html','/index.html':'index.html','/icon.svg':'icon.svg','/manifest.webmanifest':'manifest.webmanifest'};
const safeEq=(a,b)=>{const x=Buffer.from(a||''),y=Buffer.from(b||'');return x.length===y.length&&timingSafeEqual(x,y)};
const attempts=new Map();
const server=http.createServer(async(req,res)=>{
 const ip=String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim();
 const now=Date.now();const rec=attempts.get(ip)||{n:0,t:now};if(now-rec.t>60000){rec.n=0;rec.t=now}attempts.set(ip,rec);
 if(attempts.size>10000){for(const [k,v] of attempts){if(now-v.t>120000)attempts.delete(k)}}
 res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');
 const send=(code,data)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data))};
 const path=(req.url||'').split('?')[0];
 if(req.method==='GET'&&files[path]){try{const data=await readFile(join(import.meta.dirname,files[path]));res.writeHead(200,{'Content-Type':mime[path],'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});return res.end(data)}catch{return send(500,{error:'UI file unavailable'})}}
 if(path!=='/api/chat'||req.method!=='POST')return send(404,{error:'Not found'});
 if(!password||password.length<12)return send(503,{error:'JARVIS_PASSWORDを12文字以上で設定してください'});
 if(rec.n>=10)return send(429,{error:'試行回数が多すぎます。1分待ってください'});
 if(!safeEq(req.headers['x-jarvis-token'],password)){rec.n++;return send(401,{error:'接続パスワードが違います'})}rec.n=0;
 if(!key)return send(503,{error:'OPENAI_API_KEYが設定されていません'});
 try{
  let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>100000)throw Error('入力が大きすぎます')}
  const x=JSON.parse(raw);
  const input=`業務モード: ${String(x.mode||'').slice(0,100)}\n作業: ${String(x.task||'').slice(0,100)}\n案件名: ${String(x.subject||'').slice(0,300)}\n本文・指示:\n${String(x.content||'').slice(0,30000)}`;
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),80000);
  let upstream;try{upstream=await fetch('https://api.openai.com/v1/responses',{method:'POST',signal:controller.signal,headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model,instructions:'日本語で回答する業務アシスタント。青年会議所の議案レビューでは背景・目的・手法・検証・予算の整合性を具体的に確認し、重要質問と改善案を出す。事実を捏造せず、入力資料と提案を区別する。',input})})}finally{clearTimeout(timer)}
  const d=await upstream.json();if(!upstream.ok)return send(502,{error:d.error?.message||'AIサービスエラー'});
  const answer=(d.output||[]).flatMap(o=>o.content||[]).filter(c=>c.type==='output_text').map(c=>c.text).join('\n');return send(200,{text:answer||'回答がありませんでした'});
 }catch(e){return send(500,{error:String(e.message||e)})}
});
server.listen(port,'0.0.0.0',()=>console.log(`JARVIS v0.8 cloud on ${port}`));
